export default class FizzBuzz {
    CalculateSingle(integer) {
        if (integer % 15 == 0)
            return 'fizzbuzz';
        else if (integer % 5 == 0)
            return 'buzz';
        else if (integer % 3 == 0)
            return 'fizz';
        else
            return integer;
    }

    CalculateSingleLucky(integer) {
        const strint = integer.toString();

        if (strint.includes('3'))
            return 'lucky';
        else
            return this.CalculateSingle(integer);
    }

    CalculateRange(start, end, calcFunc) {

        var returnVal = "";
        for (var i = start; i <= end; i++) {
            returnVal += calcFunc(i);
            if (i != end)
                returnVal += ' ';
        }
        return returnVal;
    }

    CalculateRangeV1(start, end) {
        return this.CalculateRange(start, end, this.CalculateSingle);
    }
    CalculateRangeV2(start, end) {
        return this.CalculateRange(start, end, this.CalculateSingleLucky.bind(this));
    }
}