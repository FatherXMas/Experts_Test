#bin/bash
yarn install
yarn test

