export default class FizzBuzz {

    constructor() {
        this.totals = {}
    }

    InitialiseTotals() {
        this.totals.fizz = 0;
        this.totals.buzz = 0;
        this.totals.fizzbuzz = 0;
        this.totals.integer = 0;
        this.totals.lucky = 0;
    }

    CalculateSingle(integer) {
        if (integer % 15 == 0) {
            this.totals.fizzbuzz++;
            return 'fizzbuzz';
        }
        else if (integer % 5 == 0) {
            this.totals.buzz++;
            return 'buzz';
        }
        else if (integer % 3 == 0) {
            this.totals.fizz++;

            return 'fizz';
        }
        else {
            this.totals.integer++;
            return integer;
        }
    }

    CalculateSingleLucky(integer) {
        const strint = integer.toString();

        if (strint.includes('3')) {
            this.totals.lucky++;
            return 'lucky';
        }
        else
            return this.CalculateSingle(integer);
    }

    CalculateRange(start, end, calcFunc) {

        var returnVal = "";
        for (var i = start; i <= end; i++) {
            returnVal += calcFunc(i);
            if (i != end)
                returnVal += ' ';
        }
        return returnVal;
    }

    CalculateRangeV1(start, end) {
        return this.CalculateRange(start, end, this.CalculateSingle.bind(this));
    }
    CalculateRangeV2(start, end) {
        return this.CalculateRange(start, end, this.CalculateSingleLucky.bind(this));
    }

    CalculateRangeWithReport(start, end) {

        this.InitialiseTotals();

        var report = this.CalculateRange(start, end, this.CalculateSingleLucky.bind(this));
        report = report + ' ' +
            'fizz: ' + this.totals.fizz.toString() + ' ' +
            'buzz: ' + this.totals.buzz.toString() + ' ' +
            'fizzbuzz: ' + this.totals.fizzbuzz.toString() + ' ' +
            'lucky: ' + this.totals.lucky.toString() + ' ' +
            'integer: ' + this.totals.integer.toString();

        return report;
    }

}