rm -frv ./node_modules

git checkout step1
zip -x *.git* -r ../step1 .

git checkout step2
zip -x *.git* -r ../step2 .

git checkout step3
zip -x *.git* -r ../step3 .

cd ../
unzip -o step1.zip -d ./step1
unzip -o step1.zip -d ./step2
unzip -o step1.zip -d ./step3

cd ./step1
./build.sh

cd ../step2
./build.sh

cd ../step3
./build.sh

cd ../nodejs
git checkout master