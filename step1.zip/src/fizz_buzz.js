export default class FizzBuzz {
    CalculateSingle(integer) {
        if (integer % 15 == 0)
            return 'fizzbuzz';
        else if (integer % 5 == 0)
            return 'buzz';
        else if (integer % 3 == 0)
            return 'fizz';
        else
            return integer;
    }

    CalculateRange(start, end) {

        var returnVal = "";
        for (var i = start; i <= end; i++) {
            returnVal += this.CalculateSingle(i);
            if (i != end)
                returnVal += ' ';
        }
        return returnVal;
    }


}