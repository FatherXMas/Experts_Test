import FizzBuzz from "./fizz_buzz";

const fizzbuzz = new FizzBuzz();

describe('Real Fizzbuzz Step 1 tests', () => {

  test('CalculateSingle(1) should be 1', () => {
    expect(fizzbuzz.CalculateSingle(1)).toBe(1);
  });
  test('CalculateSingle(2) should be 2', () => {
    expect(fizzbuzz.CalculateSingle(2)).toBe(2);
  });
  test('CalculateSingle(3) should be fizz', () => {
    expect(fizzbuzz.CalculateSingle(3)).toBe('fizz');
  });
  test('CalculateSingle(4) should be 4', () => {
    expect(fizzbuzz.CalculateSingle(4)).toBe(4);
  });
  test('CalculateSingle(5) should be buzz', () => {
    expect(fizzbuzz.CalculateSingle(5)).toBe('buzz');
  });
  test('CalculateSingle(6) should be fizz', () => {
    expect(fizzbuzz.CalculateSingle(6)).toBe('fizz');
  });
  test('CalculateSingle(7) should be 7', () => {
    expect(fizzbuzz.CalculateSingle(7)).toBe(7);
  });
  test('CalculateSingle(8) should be 8', () => {
    expect(fizzbuzz.CalculateSingle(8)).toBe(8);
  });
  test('CalculateSingle(9) should be fizz', () => {
    expect(fizzbuzz.CalculateSingle(9)).toBe('fizz');
  });
  test('CalculateSingle(10) should be buzz', () => {
    expect(fizzbuzz.CalculateSingle(10)).toBe('buzz');
  });
  test('CalculateSingle(11) should be 11', () => {
    expect(fizzbuzz.CalculateSingle(11)).toBe(11);
  });
  test('CalculateSingle(12) should be fizz', () => {
    expect(fizzbuzz.CalculateSingle(12)).toBe('fizz');
  });
  test('CalculateSingle(13) should be 13', () => {
    expect(fizzbuzz.CalculateSingle(13)).toBe(13);
  });
  test('CalculateSingle(14) should be 14', () => {
    expect(fizzbuzz.CalculateSingle(14)).toBe(14);
  });
  test('CalculateSingle(15) should be fizzbuzz', () => {
    expect(fizzbuzz.CalculateSingle(15)).toBe('fizzbuzz');
  });
  test('CalculateSingle(16) should be 16', () => {
    expect(fizzbuzz.CalculateSingle(16)).toBe(16);
  });
  test('CalculateSingle(17) should be 17', () => {
    expect(fizzbuzz.CalculateSingle(17)).toBe(17);
  });
  test('CalculateSingle(18) should be fizz', () => {
    expect(fizzbuzz.CalculateSingle(18)).toBe('fizz');
  });
  test('CalculateSingle(19) should be 19', () => {
    expect(fizzbuzz.CalculateSingle(19)).toBe(19);
  });
  test('CalculateSingle(20) should be buzz', () => {
    expect(fizzbuzz.CalculateSingle(20)).toBe('buzz');
  });

  test('CalculateRange(1,20) should be 1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz', () => {
    expect(fizzbuzz.CalculateRange(1, 20)).toBe('1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz');
  });
});
